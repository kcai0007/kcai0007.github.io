# Carousel Swiper.js integration

Currently the Jetpack carousel is using the Swiper.js library to provide the slider functionality. In order to reduce the bundle size of this library a custom build is used. 

## How to generate a new custom build

- Check out the https://github.com/Automattic/swiper repo
- Switch to the `jetpack-build` branch and follow the instructions on the readme

## ToDo
- Automate this process somehow